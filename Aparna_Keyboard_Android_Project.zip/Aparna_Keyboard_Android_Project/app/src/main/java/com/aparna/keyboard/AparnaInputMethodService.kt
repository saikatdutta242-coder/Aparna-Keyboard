package com.aparna.keyboard

import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodSubtype
import java.text.BreakIterator

class AparnaInputMethodService : InputMethodService() {

    private var keyboardView: AparnaKeyboardView? = null

    override fun onCreateInputView(): View {
        val view = AparnaKeyboardView(
            context = this,
            onCommitText = { text -> commitString(text) },
            onBackspace = { handleBackspace() },
            onEnter = { handleEnter() },
            onLanguageChanged = { /* Subtype or locale updated */ }
        )
        keyboardView = view
        return view
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
    }

    override fun onCurrentInputMethodSubtypeChanged(newSubtype: InputMethodSubtype?) {
        super.onCurrentInputMethodSubtypeChanged(newSubtype)
        val localeStr = newSubtype?.locale ?: return
        val lang = when {
            localeStr.startsWith("en") -> KeyboardLanguage.ENGLISH
            localeStr == "bn_IN" -> KeyboardLanguage.VEDIC_BENGALI
            localeStr.startsWith("bn") -> KeyboardLanguage.BENGALI
            localeStr.startsWith("sa") || localeStr.startsWith("hi") -> KeyboardLanguage.DEVANAGARI
            else -> KeyboardLanguage.VEDIC_BENGALI
        }
        keyboardView?.setLanguage(lang)
    }

    private fun commitString(text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(text, 1)
    }

    private fun handleBackspace() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        // Delete 1 Unicode code point or combining mark cleanly
        val before = ic.getTextBeforeCursor(4, 0)?.toString() ?: ""
        if (before.isNotEmpty()) {
            val codePointCount = Character.codePointCount(before, 0, before.length)
            if (codePointCount >= 1) {
                val lastOffset = Character.offsetByCodePoints(before, before.length, -1)
                val charsToDelete = before.length - lastOffset
                ic.deleteSurroundingText(charsToDelete, 0)
                return
            }
        }
        ic.deleteSurroundingText(1, 0)
    }

    private fun handleEnter() {
        val ic = currentInputConnection ?: return
        val editorInfo = currentInputEditorInfo
        if (editorInfo != null && (editorInfo.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            val action = editorInfo.imeOptions and EditorInfo.IME_MASK_ACTION
            if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
                return
            }
        }
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
    }
}
