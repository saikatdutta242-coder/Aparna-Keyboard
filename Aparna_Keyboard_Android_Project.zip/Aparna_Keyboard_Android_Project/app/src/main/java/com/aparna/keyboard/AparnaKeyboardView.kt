package com.aparna.keyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

class AparnaKeyboardView(
    context: Context,
    private val onCommitText: (String) -> Unit,
    private val onBackspace: () -> Unit,
    private val onEnter: () -> Unit,
    private val onLanguageChanged: (KeyboardLanguage) -> Unit
) : LinearLayout(context) {

    var currentLanguage: KeyboardLanguage = KeyboardLanguage.VEDIC_BENGALI
        private set
    private var currentLayer: Int = 0
    private var useColorFont: Boolean = true
    private var lastConsonant: String = "ক"

    private val aparnaRegular: Typeface by lazy {
        Typeface.createFromAsset(context.assets, "fonts/Aparna-Regular.ttf")
    }
    private val aparnaBold: Typeface by lazy {
        Typeface.createFromAsset(context.assets, "fonts/Aparna-Bold.ttf")
    }
    private val aparnaColorRegular: Typeface by lazy {
        Typeface.createFromAsset(context.assets, "fonts/AparnaColor-Regular.ttf")
    }

    private val headerLayout = LinearLayout(context)
    private val smartStripScroll = HorizontalScrollView(context)
    private val smartStripContainer = LinearLayout(context)
    private val rowsContainer = LinearLayout(context)

    init {
        orientation = VERTICAL
        setBackgroundColor(Color.parseColor("#161922"))
        setPadding(dp(4), dp(6), dp(4), dp(10))

        headerLayout.orientation = HORIZONTAL
        headerLayout.gravity = Gravity.CENTER_VERTICAL
        headerLayout.setPadding(dp(4), dp(2), dp(4), dp(6))
        addView(headerLayout, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        smartStripScroll.isHorizontalScrollBarEnabled = false
        smartStripContainer.orientation = HORIZONTAL
        smartStripContainer.setPadding(dp(4), dp(2), dp(4), dp(6))
        smartStripScroll.addView(smartStripContainer)
        addView(smartStripScroll, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        rowsContainer.orientation = VERTICAL
        addView(rowsContainer, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        rebuildKeyboard()
    }

    fun setLanguage(lang: KeyboardLanguage) {
        currentLanguage = lang
        currentLayer = 0
        lastConsonant = when (lang) {
            KeyboardLanguage.ENGLISH -> "a"
            KeyboardLanguage.BENGALI -> "ক"
            KeyboardLanguage.VEDIC_BENGALI -> "ৰ"
            KeyboardLanguage.DEVANAGARI -> "क"
        }
        onLanguageChanged(lang)
        rebuildKeyboard()
    }

    private fun activeTypeface(): Typeface {
        return if (useColorFont) aparnaColorRegular else aparnaRegular
    }

    private fun applyFontFeatures(tv: TextView) {
        tv.typeface = activeTypeface()
        tv.textLocale = currentLanguage.locale
        tv.fontFeatureSettings = currentLanguage.fontFeatureSettings
    }

    private fun rebuildKeyboard() {
        buildHeader()
        buildSmartStrip()
        buildKeyRows()
    }

    private fun buildHeader() {
        headerLayout.removeAllViews()
        // 4 Language Tabs: English | বাংলা | বৈদিক-বাংলা | Devanagari
        for (lang in KeyboardLanguage.values()) {
            val active = (lang == currentLanguage)
            val tab = TextView(context).apply {
                text = lang.title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(6), dp(8), dp(6))
                setTextColor(if (active) Color.WHITE else Color.parseColor("#9CA3AF"))
                background = roundedBg(
                    if (active) "#7B2CBF" else "#222736",
                    dp(8).toFloat()
                )
                applyFontFeatures(this)
                setOnClickListener { setLanguage(lang) }
            }
            val lp = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            }
            headerLayout.addView(tab, lp)
        }

        // Layer 2 (Vedic Svara & Samaveda) quick button
        val vedicBtn = TextView(context).apply {
            text = if (currentLayer == 2) "বর্ণ" else "স্বর/সাম"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTextColor(Color.parseColor("#FFD166"))
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = roundedBg("#3B1D2E", dp(8).toFloat())
            applyFontFeatures(this)
            setOnClickListener {
                currentLayer = if (currentLayer == 2) 0 else 2
                rebuildKeyboard()
            }
        }
        headerLayout.addView(vedicBtn, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(3), 0, dp(2), 0)
        })
    }

    private fun buildSmartStrip() {
        smartStripContainer.removeAllViews()
        val suggestions = when (currentLanguage) {
            KeyboardLanguage.ENGLISH -> listOf(
                "ā", "ī", "ū", "ṛ", "ṃ", "ḥ", "ś", "ṣ", "ṇ", "॑", "॒", "᳚", "꣡", "꣢", "꣣"
            )
            KeyboardLanguage.BENGALI -> {
                val c = lastConsonant
                listOf(
                    "$cা", "$cি", "$cী", "$cু", "$cূ", "$cৃ", "$cে", "$cৈ", "$cো", "$cৌ",
                    "$c্", "${c}্য", "${c}্র", "${c}্ব", "ক্ষ", "জ্ঞ", "ঙ্ম", "চ্ঞ", "ষ্ব", "গ্ধ্র", "দ্ধ্ব"
                )
            }
            KeyboardLanguage.VEDIC_BENGALI -> {
                val c = lastConsonant
                listOf(
                    "$c॑", "$c॒", "$c᳚", "$c꣡", "$c꣢", "$c꣣",
                    "$cা", "$cি", "$cী", "$cু", "$cূ", "$cৃ", "$cৄ", "$cৢ", "$cে", "$cো",
                    "ৰ", "্ৰ", "ল়", "্ল়", "ল়্হ", "ঀ", "ঽ", "ৼ", "৾"
                )
            }
            KeyboardLanguage.DEVANAGARI -> {
                val c = lastConsonant
                listOf(
                    "$c॑", "$c॒", "$c᳚", "$c꣡", "$c꣢", "$c꣣",
                    "$cा", "$cि", "$cी", "$cु", "$cू", "$cृ", "$cॄ", "$cॢ", "$cे", "$cो",
                    "ॐ", "ऽ", "ळ", "क्ष", "त्र", "ज्ञ", "ङ्म", "च्ञ", "ष्व", "ग्ध्र", "द्ध्व"
                )
            }
        }

        for (item in suggestions) {
            val chip = TextView(context).apply {
                text = item
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                setTextColor(Color.parseColor("#F3F4F6"))
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = roundedBg("#242938", dp(6).toFloat())
                applyFontFeatures(this)
                setOnClickListener { onCommitText(item) }
            }
            smartStripContainer.addView(chip, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
    }

    private fun buildKeyRows() {
        rowsContainer.removeAllViews()
        val rows = KeyboardLayouts.getRows(currentLanguage, currentLayer)

        for (row in rows) {
            val rowLayout = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER
            }
            for (key in row) {
                val keyBtn = TextView(context).apply {
                    text = key.label
                    gravity = Gravity.CENTER
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, if (key.label.length > 2) 12f else 17f)
                    setTextColor(
                        when {
                            key.isVedicAccent -> Color.parseColor("#FFD166")
                            key.isSpecial -> Color.parseColor("#CBD5E1")
                            else -> Color.WHITE
                        }
                    )
                    background = roundedBg(
                        when {
                            key.isVedicAccent -> "#3B1D2E"
                            key.isSpecial -> "#1C202E"
                            else -> "#262C3C"
                        },
                        dp(6).toFloat()
                    )
                    setPadding(dp(2), dp(10), dp(2), dp(10))
                    applyFontFeatures(this)
                    setOnClickListener { handleKeyPress(key) }
                }
                val lp = LayoutParams(0, LayoutParams.WRAP_CONTENT, key.weight).apply {
                    setMargins(dp(2), dp(3), dp(2), dp(3))
                }
                rowLayout.addView(keyBtn, lp)
            }
            rowsContainer.addView(rowLayout, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        }

        // Bottom Row: [123/০৯] [🌐 ভাষা] [হসন্ত/্] [Spacebar (Current Language)] [। / .] [⏎]
        val bottomRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        val numBtn = createBottomKey(
            label = if (currentLayer == 3) "ABC/ক" else "123/০৯",
            weight = 1.2f,
            bg = "#1C202E"
        ) {
            currentLayer = if (currentLayer == 3) 0 else 3
            rebuildKeyboard()
        }

        val globeBtn = createBottomKey(
            label = "🌐 ${currentLanguage.shortBadge}",
            weight = 1.3f,
            bg = "#2D3548"
        ) {
            setLanguage(currentLanguage.next())
        }

        val viramaChar = when (currentLanguage) {
            KeyboardLanguage.ENGLISH -> "ʼ"
            KeyboardLanguage.DEVANAGARI -> "्"
            else -> "্"
        }
        val viramaBtn = createBottomKey(
            label = viramaChar,
            weight = 1.0f,
            bg = "#3B1D2E"
        ) {
            onCommitText(viramaChar)
        }

        val spaceBtn = createBottomKey(
            label = currentLanguage.spacebarLabel,
            weight = 3.8f,
            bg = "#2E3548"
        ) {
            onCommitText(" ")
        }
        spaceBtn.setOnLongClickListener {
            setLanguage(currentLanguage.next())
            true
        }

        val dandaChar = if (currentLanguage == KeyboardLanguage.ENGLISH) "." else "।"
        val dandaBtn = createBottomKey(
            label = dandaChar,
            weight = 1.0f,
            bg = "#262C3C"
        ) {
            onCommitText(dandaChar)
        }

        val enterBtn = createBottomKey(
            label = "⏎",
            weight = 1.3f,
            bg = "#7B2CBF"
        ) {
            onEnter()
        }

        for (v in listOf(numBtn, globeBtn, viramaBtn, spaceBtn, dandaBtn, enterBtn)) {
            bottomRow.addView(v)
        }
        rowsContainer.addView(bottomRow, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    private fun createBottomKey(label: String, weight: Float, bg: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.WHITE)
            background = roundedBg(bg, dp(6).toFloat())
            setPadding(dp(4), dp(11), dp(4), dp(11))
            applyFontFeatures(this)
            setOnClickListener { onClick() }
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
        }
    }

    private fun handleKeyPress(key: KeySpec) {
        when (key.output) {
            "BACKSPACE" -> onBackspace()
            "LAYER_0" -> { currentLayer = 0; rebuildKeyboard() }
            "LAYER_1" -> { currentLayer = 1; rebuildKeyboard() }
            "LAYER_2" -> { currentLayer = 2; rebuildKeyboard() }
            "LAYER_3" -> { currentLayer = 3; rebuildKeyboard() }
            else -> {
                onCommitText(key.output)
                if (key.output.length in 1..2 && !key.isVedicAccent) {
                    lastConsonant = key.output
                    buildSmartStrip()
                }
            }
        }
    }

    private fun roundedBg(hex: String, radius: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(Color.parseColor(hex))
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
