package com.aparna.keyboard

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editor: EditText
    private lateinit var keyboardPreview: AparnaKeyboardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val aparnaColor = Typeface.createFromAsset(assets, "fonts/AparnaColor-Regular.ttf")
        val aparnaBold = Typeface.createFromAsset(assets, "fonts/Aparna-Bold.ttf")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F1219"))
        }

        val topScroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 40, 36, 24)
        }

        val titleView = TextView(this).apply {
            text = "Aparna Multi-Language Keyboard (v1.0)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTextColor(Color.WHITE)
            typeface = aparnaBold
        }
        content.addView(titleView)

        val subView = TextView(this).apply {
            text = "English • বাংলা • বৈদিক-বাংলা • Devanagari | Aparna & Aparna Color v1.0"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#9CA3AF"))
            typeface = aparnaColor
            setPadding(0, 6, 0, 20)
        }
        content.addView(subView)

        // Setup Buttons Row
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val enableBtn = Button(this).apply {
            text = "১. কিবোর্ড সক্রিয় করুন"
            typeface = aparnaBold
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }
        val selectBtn = Button(this).apply {
            text = "২. কিবোর্ড নির্বাচন করুন"
            typeface = aparnaBold
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        btnRow.addView(enableBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        btnRow.addView(selectBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(btnRow)

        // Built-in Vedic & Multi-Language Editor with Aparna Color v1.0
        editor = EditText(this).apply {
            typeface = aparnaColor
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#6B7280"))
            setBackgroundColor(Color.parseColor("#1B2030"))
            setPadding(28, 28, 28, 28)
            minLines = 5
            gravity = Gravity.TOP or Gravity.START
            fontFeatureSettings = ""ss01" 1, "kern" 1, "liga" 1"
            setText(
                "ঀ অগ্নি꣡মী꣢ল়ে পু꣣রোহি꣢তং যজ্ঞ꣡স্য দে꣢বমৃ꣣ত্বিজম্ । হোতা꣢রং রত্নধা꣡তমম্ ॥
" +
                "ॐ अग्नि꣡मी꣢ळे पु꣣रोहि꣢तं यज्ञ꣡स्य दे꣢वमृ꣣त्विजम् । होता꣢रं रत्नधा꣡तमम् ॥
" +
                "oṁ agni꣡mī꣢ḷe pu꣣rohi꣢taṁ yajña꣡sya de꣢vamṛ꣣tvijam ।"
            )
            showSoftInputOnFocus = false
        }
        content.addView(editor, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 20 })

        topScroll.addView(content)
        root.addView(topScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        // Embedded Live Keyboard View at bottom of Companion App
        keyboardPreview = AparnaKeyboardView(
            context = this,
            onCommitText = { txt ->
                val start = editor.selectionStart.coerceAtLeast(0)
                val end = editor.selectionEnd.coerceAtLeast(0)
                editor.text.replace(minOf(start, end), maxOf(start, end), txt, 0, txt.length)
            },
            onBackspace = {
                val start = editor.selectionStart
                val end = editor.selectionEnd
                if (start != end && start >= 0 && end >= 0) {
                    editor.text.delete(minOf(start, end), maxOf(start, end))
                } else if (start > 0) {
                    editor.text.delete(start - 1, start)
                }
            },
            onEnter = {
                val start = editor.selectionStart.coerceAtLeast(0)
                editor.text.insert(start, "
")
            },
            onLanguageChanged = { lang ->
                editor.textLocale = lang.locale
                editor.fontFeatureSettings = lang.fontFeatureSettings
            }
        )
        root.addView(keyboardPreview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        setContentView(root)
    }
}
