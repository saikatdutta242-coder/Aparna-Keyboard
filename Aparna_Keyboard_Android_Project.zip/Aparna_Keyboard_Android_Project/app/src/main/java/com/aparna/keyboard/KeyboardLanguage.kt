package com.aparna.keyboard

import java.util.Locale

enum class KeyboardLanguage(
    val id: String,
    val title: String,
    val shortBadge: String,
    val locale: Locale,
    val fontFeatureSettings: String,
    val spacebarLabel: String
) {
    ENGLISH(
        id = "EN",
        title = "English",
        shortBadge = "EN",
        locale = Locale.ENGLISH,
        fontFeatureSettings = ""ss02" 1, "kern" 1, "liga" 1",
        spacebarLabel = "English • IAST (Aparna v1.0)"
    ),
    BENGALI(
        id = "BN",
        title = "বাংলা",
        shortBadge = "বাংলা",
        locale = Locale("bn", "BD"),
        fontFeatureSettings = ""ss01" 1, "kern" 1, "liga" 1",
        spacebarLabel = "বাংলা • Aparna v1.0"
    ),
    VEDIC_BENGALI(
        id = "VED_BN",
        title = "বৈদিক-বাংলা",
        shortBadge = "বৈদিক",
        locale = Locale("bn", "IN"),
        fontFeatureSettings = ""ss01" 1, "kern" 1, "liga" 1",
        spacebarLabel = "বৈদিক-বাংলা • ৰ ল় ॑ ॒ ꣡"
    ),
    DEVANAGARI(
        id = "DEVA",
        title = "Devanagari",
        shortBadge = "देव",
        locale = Locale("sa", "IN"),
        fontFeatureSettings = ""kern" 1, "liga" 1",
        spacebarLabel = "देवनागरी • वैदिक संस्कृत"
    );

    fun next(): KeyboardLanguage {
        val vals = values()
        return vals[(ordinal + 1) % vals.size]
    }
}
