package com.aparna.keyboard

data class KeySpec(
    val label: String,
    val output: String = label,
    val hint: String = "",
    val weight: Float = 1f,
    val isSpecial: Boolean = false,
    val isVedicAccent: Boolean = false
)

object KeyboardLayouts {

    // 4 sub-layers available per language:
    // Layer 0: Primary Letters & Matras
    // Layer 1: Shift / Extended / Conjuncts & Phalas
    // Layer 2: Vedic Svara, Samaveda (꣠..꣱) & Vedic Extensions (᳐..ᳺ)
    // Layer 3: Numbers (Tabular/Proportional) & Symbols

    fun getRows(lang: KeyboardLanguage, layer: Int): List<List<KeySpec>> {
        return when (lang) {
            KeyboardLanguage.ENGLISH -> getEnglishRows(layer)
            KeyboardLanguage.BENGALI -> getBengaliRows(layer)
            KeyboardLanguage.VEDIC_BENGALI -> getVedicBengaliRows(layer)
            KeyboardLanguage.DEVANAGARI -> getDevanagariRows(layer)
        }
    }

    private fun getEnglishRows(layer: Int): List<List<KeySpec>> {
        return when (layer) {
            1 -> listOf(
                listOf("Q","W","E","R","T","Y","U","I","O","P").map { KeySpec(it) },
                listOf("A","S","D","F","G","H","J","K","L").map { KeySpec(it) },
                listOf(KeySpec("⇧", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("Z","X","C","V","B","N","M").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            2 -> listOf(
                // IAST & Roman Vedic Transliteration + Roman Samaveda (ss02)
                listOf("ā","ī","ū","ṛ","ṝ","ḷ","ḹ","ē","ō","ṃ","ḥ").map { KeySpec(it) },
                listOf("ṅ","ñ","ṭ","ḍ","ṇ","ś","ṣ","ḫ","ẖ","ṁ","ʼ").map { KeySpec(it) },
                listOf("॑","॒","᳚","́","̀","̂","꣡","꣢","꣣","꣤","꣥").map { KeySpec(it, isVedicAccent = true) },
                listOf(KeySpec("ABC", "LAYER_0", isSpecial = true, weight = 1.3f)) +
                    listOf("꣦","꣧","꣨","꣩","꣪","꣫","꣬","꣭","꣮").map { KeySpec(it, isVedicAccent = true) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.3f))
            )
            3 -> listOf(
                listOf("1","2","3","4","5","6","7","8","9","0").map { KeySpec(it) },
                listOf("@","#","$","%","&","-","+","(",")","/").map { KeySpec(it) },
                listOf(KeySpec("ABC", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("*",""","'",":",";","!","?","—").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            else -> listOf(
                listOf("q","w","e","r","t","y","u","i","o","p").map { KeySpec(it) },
                listOf("a","s","d","f","g","h","j","k","l").map { KeySpec(it) },
                listOf(KeySpec("⇧", "LAYER_1", isSpecial = true, weight = 1.4f)) +
                    listOf("z","x","c","v","b","n","m").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
        }
    }

    private fun getBengaliRows(layer: Int): List<List<KeySpec>> {
        return when (layer) {
            1 -> listOf(
                // ফলা ও জনপ্রিয় যুক্তবর্ণ (Phalas & Conjuncts)
                listOf("্য","্র","র্","্ব","্ল","্ন","্ম","ক্ষ","জ্ঞ","ত্র").map { KeySpec(it) },
                listOf("ঙ্ম","চ্ঞ","ষ্ব","গ্ধ্র","দ্ধ্ব","ত্ত","ক্ত","প্র","শ্র","স্ত্র").map { KeySpec(it) },
                listOf("ড়","ঢ়","য়","ৎ","ং","ঃ","ঁ","ঈ","ঊ","ঐ","ঔ").map { KeySpec(it) },
                listOf(KeySpec("কখগ", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("ঞ","ঙ","ণ","য","শ","ষ","।","॥").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            2 -> listOf(
                // বাংলা বৈদিক ও সামবেদ চিহ্ন
                listOf("॑","॒","᳚","॓","॔","ঀ","ঽ","ৼ","৾","᳷").map { KeySpec(it, isVedicAccent = true) },
                listOf("꣠","꣡","꣢","꣣","꣤","꣥","꣦","꣧","꣨","꣩").map { KeySpec(it, isVedicAccent = true) },
                listOf("꣪","꣫","꣬","꣭","꣮","꣯","꣰","꣱","ৰ","ল়").map { KeySpec(it, isVedicAccent = true) },
                listOf(KeySpec("কখগ", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("ৠ","ঌ","ৡ","ৄ","ৢ","ৣ","।","॥").map { KeySpec(it, isVedicAccent = true) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            3 -> listOf(
                listOf("১","২","৩","৪","৫","৬","৭","৮","৯","০").map { KeySpec(it) },
                listOf("৳","%","+","-","×","÷","=","(",")","/").map { KeySpec(it) },
                listOf(KeySpec("কখগ", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("।","॥","‘","’","“","”","—","?").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            else -> listOf(
                // স্বরবর্ণ ও কার-মাত্রা
                listOf("অ","আ","ই","উ","ঋ","এ","ও","া","ি","ী","ু","ূ").map { KeySpec(it) },
                listOf("ৃ","ে","ৈ","ো","ৌ","্","ক","খ","গ","ঘ","চ","ছ").map { KeySpec(it) },
                listOf("জ","ঝ","ট","ঠ","ড","ঢ","ত","থ","দ","ধ","ন","প").map { KeySpec(it) },
                listOf(KeySpec("যুক্ত/ফলা", "LAYER_1", isSpecial = true, weight = 1.4f)) +
                    listOf("ফ","ব","ভ","ম","র","ল","স","হ","ং","ঁ").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
        }
    }

    private fun getVedicBengaliRows(layer: Int): List<List<KeySpec>> {
        return when (layer) {
            1 -> listOf(
                // বৈদিক যুক্তবর্ণ, ফলা ও বিশেষ বর্ণ
                listOf("ৰ","্ৰ","ল়","্ল়","ল়্হ","্য","্র","র্","্ব","্ম").map { KeySpec(it, isVedicAccent = true) },
                listOf("ঙ্ম","চ্ঞ","ষ্ব","গ্ধ্র","দ্ধ্ব","ক্ষ","জ্ঞ","ত্ত","ক্ত","স্ত্র").map { KeySpec(it) },
                listOf("ৠ","ঌ","ৡ","ৄ","ৢ","ৣ","ঀ","ঽ","ৼ","৾").map { KeySpec(it, isVedicAccent = true) },
                listOf(KeySpec("বৈদিক ১", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("ঙ","ঞ","ণ","য","ড়","ঢ়","য়","ৎ").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            2 -> listOf(
                // সামবেদ স্বর-সংখ্যা (꣠-꣩ -> বাংলা ০-৯), স্বর-অক্ষর (꣪-꣱) ও বৈদিক এক্সটেনশন
                listOf("꣠","꣡","꣢","꣣","꣤","꣥","꣦","꣧","꣨","꣩").map { KeySpec(it, isVedicAccent = true) },
                listOf("꣪","꣫","꣬","꣭","꣮","꣯","꣰","꣱","॑","॒").map { KeySpec(it, isVedicAccent = true) },
                listOf("᳚","॓","॔","᳐","᳑","᳒","᳓","᳔","᳕","᳖").map { KeySpec(it, isVedicAccent = true) },
                listOf(KeySpec("বৈদিক ১", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("᳗","᳘","᳙","᳚","᳛","᳜","᳝","᳷","᳸","᳹").map { KeySpec(it, isVedicAccent = true) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            3 -> listOf(
                listOf("১","২","৩","৪","৫","৬","৭","৮","৯","০").map { KeySpec(it) },
                listOf("꣠","꣡","꣢","꣣","꣤","꣥","꣦","꣧","꣨","꣩").map { KeySpec(it, isVedicAccent = true) },
                listOf(KeySpec("বৈদিক ১", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("।","॥","ঀ","ঽ","ৼ","৾","‘","’").map { KeySpec(it, isVedicAccent = true) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            else -> listOf(
                // বৈদিক-বাংলা প্রাইমারি লেআউট: স্বরচিহ্ন + ৰ + ল় + বাংলা বর্ণ
                listOf("॑","॒","᳚","ৰ","্ৰ","ল়","্ল়","ঀ","ঽ","ৄ","ৢ","ৣ").map { KeySpec(it, isVedicAccent = true) },
                listOf("অ","আ","ই","ঈ","উ","ঊ","ঋ","ৠ","ঌ","এ","ঐ","ও","ঔ").map { KeySpec(it) },
                listOf("া","ি","ী","ু","ূ","ৃ","ে","ৈ","ো","ৌ","্","ং","ঃ","ঁ").map { KeySpec(it) },
                listOf("ক","খ","গ","ঘ","চ","ছ","জ","ঝ","ট","ঠ","ড","ঢ","ণ").map { KeySpec(it) },
                listOf(KeySpec("যুক্ত/সাম", "LAYER_1", isSpecial = true, weight = 1.3f)) +
                    listOf("ত","থ","দ","ধ","ন","প","ফ","ব","ভ","ম","য","র","ল","শ","ষ","স","হ").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.3f))
            )
        }
    }

    private fun getDevanagariRows(layer: Int): List<List<KeySpec>> {
        return when (layer) {
            1 -> listOf(
                // संयुक्त अक्षर एवं वैदिक वर्ण
                listOf("्र","्य","र्","क्ष","त्र","ज्ञ","श्र","द्ध","द्व","क्त").map { KeySpec(it) },
                listOf("ङ्म","च्ञ","ष्व","ग्ध्र","द्ध्व","ळ","क़","ख़","ग़","ज़").map { KeySpec(it) },
                listOf("ॠ","ऌ","ॡ","ॄ","ॢ","ॣ","ॐ","ऽ","ड़","ढ़").map { KeySpec(it, isVedicAccent = true) },
                listOf(KeySpec("कखग", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("ङ","ञ","ण","श","ष","।","॥","॰").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            2 -> listOf(
                // वैदिक स्वर एवं सामवेद (Devanagari Samaveda ꣠..ꣿ)
                listOf("॑","॒","᳚","॓","॔","ॐ","ऽ","᳷","᳸","᳹").map { KeySpec(it, isVedicAccent = true) },
                listOf("꣠","꣡","꣢","꣣","꣤","꣥","꣦","꣧","꣨","꣩").map { KeySpec(it, isVedicAccent = true) },
                listOf("꣪","꣫","꣬","꣭","꣮","꣯","꣰","꣱","ꣲ","ꣳ").map { KeySpec(it, isVedicAccent = true) },
                listOf(KeySpec("कखग", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("᳐","᳑","᳒","᳓","᳔","᳕","᳖","।","॥").map { KeySpec(it, isVedicAccent = true) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            3 -> listOf(
                listOf("१","२","३","४","५","६","७","८","९","०").map { KeySpec(it) },
                listOf("₹","%","+","-","×","÷","=","(",")","/").map { KeySpec(it) },
                listOf(KeySpec("कखग", "LAYER_0", isSpecial = true, weight = 1.4f)) +
                    listOf("।","॥","ॐ","ऽ","॰","卐","‘","’").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.4f))
            )
            else -> listOf(
                listOf("अ","आ","इ","ई","उ","ऊ","ऋ","ए","ऐ","ओ","औ","ॐ").map { KeySpec(it) },
                listOf("ा","ि","ी","ु","ू","ृ","े","ै","ो","ौ","्","ं","ः","ँ").map { KeySpec(it) },
                listOf("क","ख","ग","घ","च","छ","ज","झ","ट","ठ","ड","ढ","ण").map { KeySpec(it) },
                listOf(KeySpec("संयुक्त", "LAYER_1", isSpecial = true, weight = 1.3f)) +
                    listOf("त","थ","द","ध","न","प","फ","ब","भ","म","य","र","ल","ळ","व","श","ष","स","ह").map { KeySpec(it) } +
                    listOf(KeySpec("⌫", "BACKSPACE", isSpecial = true, weight = 1.3f))
            )
        }
    }
}
