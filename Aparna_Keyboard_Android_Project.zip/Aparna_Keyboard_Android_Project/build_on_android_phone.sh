#!/data/data/com.termux/files/usr/bin/bash
# পিসি ছাড়াই সরাসরি অ্যান্ড্রয়েড ফোনে (AndroidIDE বা Termux-এ) APK বিল্ড করার স্ক্রিপ্ট
echo "=========================================================="
echo "  Aparna Multi-Language Keyboard v1.0 - Android Builder   "
echo "=========================================================="
if command -v gradle >/dev/null 2>&1; then
    gradle assembleDebug --no-daemon
    echo "✅ সফলভাবে APK তৈরি হয়েছে: app/build/outputs/apk/debug/app-debug.apk"
else
    echo "ℹ️ আপনার ফোনে AndroidIDE অ্যাপে এই ফোল্ডারটি ওপেন করে 'Run / Build APK' বাটনে ট্যাপ করুন,"
    echo "অথবা GitHub-এ আপলোড করে Actions ট্যাব থেকে সরাসরি রেডিমেড APK ডাউনলোড করুন।"
fi
